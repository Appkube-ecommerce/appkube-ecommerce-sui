import React from 'react'

const Analytics = () => {
  return (
    <div>Analytics important</div>
  )
}

export default Analytics