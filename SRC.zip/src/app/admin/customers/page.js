import React from 'react'
import Customers from '@/components/admin/customers/customers'
const App = () => {
  return (
    <div><Customers/></div>
  )
}

export default App