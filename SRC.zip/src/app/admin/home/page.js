import React from 'react'
import Home from '@/components/admin/home/home'
const App = () => {
  return (
    <div><Home/></div>
  )
}

export default App