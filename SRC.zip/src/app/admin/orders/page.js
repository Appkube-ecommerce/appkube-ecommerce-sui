import React from 'react'
import Orders from '@/components/admin/orders/orders'
const App = () => {
  return (
    <div><Orders/></div>
  )
}

export default App