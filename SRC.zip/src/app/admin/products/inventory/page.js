import React from 'react'
import Inventory from '@/components/admin/products/inventory/inventory'
const App = () => {
  return (
    <div><Inventory/></div>
  )
}

export default App