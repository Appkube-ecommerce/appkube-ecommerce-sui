import React from 'react'
import Products from '@/components/admin/products/products'
const App = () => {
  return (
    <div><Products /></div>
  )
}

export default App