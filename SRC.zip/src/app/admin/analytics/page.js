import React from 'react'
import Analytics from '@/components/admin/analytics/analytics'
const App = () => {
  return (
    <div><Analytics/></div>
  )
}

export default App