import React from "react";
import Myorders from "@/components/order_processing/order";
import Timeline from "@/components/order_processing/timeline";
const Order = () => {
  return (
    <div>
        <Timeline />
      <Myorders />
    </div>
  );
};

export default Order;
