// import ProductCards from '@/components/buyer/home/ProductCards'
import ProductPage from '@/components/buyer/productPage/productPage'
import React from 'react'

const page = () => {
  return (
    <ProductPage/>
  )
}

export default page